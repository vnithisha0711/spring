package com.cg.employees.exceptions;

public class UsernameAlreadyExistsException extends RuntimeException{

	
	private static final long serialVersionUID = 1L;

	 public UsernameAlreadyExistsException() {
	        super();
	        // TODO Auto-generated constructor stub
	    }

	 

	    public UsernameAlreadyExistsException(String message) {
	        super(message);
	        // TODO Auto-generated constructor stub
	    }
}
